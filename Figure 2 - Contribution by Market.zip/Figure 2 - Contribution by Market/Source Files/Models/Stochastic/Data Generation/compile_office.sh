rm ./a.out
g++ -O3 -I /Library/gurobi951/macos_universal2/include -L /Library/gurobi951/macos_universal2/lib -lgurobi_c++ -lgurobi95 -Ofast *.cpp
