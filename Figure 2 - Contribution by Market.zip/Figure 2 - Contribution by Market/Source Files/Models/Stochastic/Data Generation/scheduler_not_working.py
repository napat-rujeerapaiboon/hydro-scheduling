import os
import sys
import time

for i in range (364):
    while True:
        os.system ('qstat | grep "energy.pbs" | wc -l > temp.txt')
        with open('temp.txt') as f:
            contents = f.read()
        if int(contents) < 25:
            break
        time.sleep(60)
            
    if i == 0:
        os.system ('qsub -J 0-249 energy.pbs > jobno.txt')
    else:
        os.system ('qsub -J 0-249 -W depend=afterany:' + lastjobno + ' energy.pbs > jobno.txt')

    time.sleep(60)
        
    with open('jobno.txt') as f:
        contents = f.read()
    lastjobno = contents[:-7]
