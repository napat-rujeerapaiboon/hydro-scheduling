//
//  master_problem.hpp
//  Hydroscheduling
//
//  Created by Wolfram Wiesemann on 01/12/2020.
//  Copyright © 2020 Wolfram Wiesemann. All rights reserved.
//

#ifndef master_problem_hpp
#define master_problem_hpp

#include <string>
#include <vector>

double solve_master_problem (std::vector<double> &water_values, std::vector<double> &water_target_levels, double &violation);

#endif /* master_problem_hpp */
