rm ./a.out
g++ *.cpp -std=c++11 -I ~/gurobi951/linux64/include -L ~/gurobi951/linux64/lib -lgurobi_c++ -lgurobi95 -Ofast
