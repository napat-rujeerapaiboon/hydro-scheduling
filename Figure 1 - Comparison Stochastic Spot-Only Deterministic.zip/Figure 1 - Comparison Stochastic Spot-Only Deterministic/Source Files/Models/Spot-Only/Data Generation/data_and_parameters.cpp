//
//  data_and_parameters.cpp
//  Hydroscheduling
//
//  Created by Wolfram Wiesemann on 01/12/2020.
//  Copyright © 2020 Wolfram Wiesemann. All rights reserved.
//

#include "data_and_parameters.hpp"

#include "auxiliary.hpp"

using namespace std;

// initial_reservoir_level is the water level at the beginning of the current day
double          initial_reservoir_level[no_of_reservoirs];

// all prices start from the beginning of the year
// in-sample spot prices coincide with out-of-sample spot prices for past as well as current day
// in-sample reserve prices coincide with out-of-sample reserve prices for past
vector<double>  spot_price__in_sample;                       // [no_of_hours_per_year]

vector<double>  reserve_up__capacity_fee__in_sample;         // [no_of_hours_per_year]
vector<double>  reserve_down__capacity_fee__in_sample;       // [no_of_hours_per_year]
vector<double>  reserve_up__var_price__in_sample;            // [no_of_hours_per_year * 4]
vector<double>  reserve_down__var_price__in_sample;          // [no_of_hours_per_year * 4]

vector<double>  spot_price__out_of_sample;                   // [no_of_hours_per_year]

vector<double>  reserve_up__capacity_fee__out_of_sample;     // [no_of_hours_per_year]
vector<double>  reserve_down__capacity_fee__out_of_sample;   // [no_of_hours_per_year]
vector<double>  reserve_up__var_price__out_of_sample;        // [no_of_hours_per_year * 4]
vector<double>  reserve_down__var_price__out_of_sample;      // [no_of_hours_per_year * 4]


// all inflows start from the beginning of the year
// in-sample inflows coincide with out-of-sample inflows for past as well as current day
vector<vector<vector<double> > > inflows__in_sample;                    // [no_of_insample_scenarios][no_of_reservoirs][no_of_hours_per_year]
vector<vector<double> >          inflows__out_of_sample;                // [no_of_reservoirs][no_of_hours_per_year]

int             current_day = -1;                            // which day of the time horizon are we considering (starting from 0)?

int             target_reserve_success_probability_first_stage__hourly_granularity__index;
int             target_success_frequency_second_stage__5_second_granularity__index;


void find_bids_for_day (int day, double &cap_fee_up, double &cap_fee_down, double &var_price_up, double &var_price_down) {
    // capacity fees
    vector<double> cap_fees_up, cap_fees_down;
    vector<double> var_prices_up, var_prices_down;
    
    for (int h = 0; h < no_of_hours_per_day; ++h) {
        cap_fees_up.push_back (reserve_up__capacity_fee__in_sample[day * no_of_hours_per_day + h]);
        cap_fees_down.push_back (reserve_down__capacity_fee__in_sample[day * no_of_hours_per_day + h]);
        
        for (int i = 0; i < 4; ++i) {
            var_prices_up.push_back (reserve_up__var_price__in_sample[(day * no_of_hours_per_day + h) * 4 + i]);
            var_prices_down.push_back (reserve_down__var_price__in_sample[(day * no_of_hours_per_day + h) * 4 + i]);
        }
    }
    
    cap_fee_up = quantile (1.0 - first_stage__probs[target_reserve_success_probability_first_stage__hourly_granularity__index], cap_fees_up);
    cap_fee_down = quantile (1.0 - first_stage__probs[target_reserve_success_probability_first_stage__hourly_granularity__index], cap_fees_down);
    var_price_up = quantile (1.0 - second_stage__probs[target_success_frequency_second_stage__5_second_granularity__index], var_prices_up);
    var_price_down = quantile (second_stage__probs[target_success_frequency_second_stage__5_second_granularity__index], var_prices_down);
}
