//
//  input_data_io.cpp
//  Hydroscheduling
//
//  Created by Wolfram Wiesemann on 01/12/2020.
//  Copyright © 2020 Wolfram Wiesemann. All rights reserved.
//

#include "input_data_io.hpp"

#include <random>
#include <vector>
#include <fstream>
#include <iomanip>
#include <sstream>
#include <iostream>
#include <algorithm>

#include "auxiliary.hpp"
#include "data_and_parameters.hpp"

using namespace std;

default_random_engine generator;

// read the input data -- current_day needed to set in-sample data equal to out-of-sample data for past + (partly) present
void read_data() {
    stringstream filename;

    if ((current_day < 0) || (current_day >= no_of_days_per_year))
        error ("read_data", "current_day is set to an inadmissible value.");
    
    tic();
    
    /*
     ***********************
     *** SPOT PRICE DATA ***
     ***********************
     */
    
    tic();
    cout << "Spot price data..." << flush;

    // open spot price raw input data file
    filename << directory << "/proc/spot_price_data.txt";
    
    ifstream fin_spot (filename.str().c_str());
    if (!fin_spot.is_open()) error ("read_data", "Spot price data file \'spot_price_data.txt\' not found.");

    // read spot price data file
    spot_price__in_sample.resize (no_of_hours_per_year);
    spot_price__out_of_sample.resize (no_of_hours_per_year);

    for (int t = 0; t < no_of_hours_per_year; ++t) {
        fin_spot >> spot_price__out_of_sample[t];
        if (fin_spot.eof()) error ("read_data", "Unexpected end of spot price data file.");

        fin_spot >> spot_price__in_sample[t];
        if (fin_spot.eof()) error ("read_data", "Unexpected end of spot price data file.");
        spot_price__in_sample[t] = exp (spot_price__in_sample[t]);
    }

    double variance_of_log_residuals;
    fin_spot >> variance_of_log_residuals;
    if (fin_spot.eof()) error ("read_data", "Unexpected end of spot price data file.");

    // ensure that in-sample spot prices of past and current day coincide with out-of-sample spot prices
    for (int d = 0; d <= current_day; ++d)
        for (int h = 0; h < no_of_hours_per_day; ++h)
            spot_price__in_sample[d * no_of_hours_per_day + h] = spot_price__out_of_sample[d * no_of_hours_per_day + h];
    
    cout << "done: " << toc() << " seconds." << endl;
    

    /*
     **************************
     *** RESERVE PRICE DATA ***
     **************************
     */

    tic();
    cout << "Reserve price data..." << flush;

    // open reserve price data files
    filename.str (string());
    filename << directory << "/proc/reserve_up_capacity_fee_data.txt";
    ifstream fin_reserve_up_cap_fee (filename.str().c_str());
    if (!fin_reserve_up_cap_fee.is_open()) error ("read_data", "Reserve price data file \'reserve_up_capacity_fee_data.txt\' not found.");

    filename.str (string());
    filename << directory << "/proc/reserve_down_capacity_fee_data.txt";
    ifstream fin_reserve_down_cap_fee (filename.str().c_str());
    if (!fin_reserve_down_cap_fee.is_open()) error ("read_data", "Reserve price data file \'reserve_down_capacity_fee_data.txt\' not found.");

    filename.str (string());
    filename << directory << "/proc/reserve_up_var_price_data.txt";
    ifstream fin_reserve_up_var_price (filename.str().c_str());
    if (!fin_reserve_up_var_price.is_open()) error ("read_data", "Reserve price data file \'reserve_up_var_price_data.txt\' not found.");

    filename.str (string());
    filename << directory << "/proc/reserve_down_var_price_data.txt";
    ifstream fin_reserve_down_var_price (filename.str().c_str());
    if (!fin_reserve_down_var_price.is_open()) error ("read_data", "Reserve price data file \'reserve_down_var_price_data.txt\' not found.");
    
    // read reserve price data files
    reserve_up__capacity_fee__in_sample.resize (no_of_hours_per_year);
    reserve_down__capacity_fee__in_sample.resize (no_of_hours_per_year);
    reserve_up__var_price__in_sample.resize (no_of_hours_per_year * 4);
    reserve_down__var_price__in_sample.resize (no_of_hours_per_year * 4);

    reserve_up__capacity_fee__out_of_sample.resize (no_of_hours_per_year);
    reserve_down__capacity_fee__out_of_sample.resize (no_of_hours_per_year);
    reserve_up__var_price__out_of_sample.resize (no_of_hours_per_year * 4);
    reserve_down__var_price__out_of_sample.resize (no_of_hours_per_year * 4);

    for (int t = 0; t < no_of_hours_per_year; ++t) {
        fin_reserve_up_cap_fee >> reserve_up__capacity_fee__out_of_sample[t];
        if (fin_reserve_up_cap_fee.eof()) error ("read_data", "Unexpected end of reserve price data file.");

        fin_reserve_up_cap_fee >> reserve_up__capacity_fee__in_sample[t];
        if (fin_reserve_up_cap_fee.eof()) error ("read_data", "Unexpected end of reserve price data file.");
        reserve_up__capacity_fee__in_sample[t] = exp (reserve_up__capacity_fee__in_sample[t]);

        fin_reserve_down_cap_fee >> reserve_down__capacity_fee__out_of_sample[t];
        if (fin_reserve_down_cap_fee.eof()) error ("read_data", "Unexpected end of reserve price data file.");

        fin_reserve_down_cap_fee >> reserve_down__capacity_fee__in_sample[t];
        if (fin_reserve_down_cap_fee.eof()) error ("read_data", "Unexpected end of reserve price data file.");
        reserve_down__capacity_fee__in_sample[t] = exp (reserve_down__capacity_fee__in_sample[t]);

        for (int i = 0; i < 4; ++i) {
            fin_reserve_up_var_price >> reserve_up__var_price__out_of_sample[t * 4 + i];
            if (fin_reserve_up_var_price.eof()) error ("read_data", "Unexpected end of reserve price data file.");

            fin_reserve_down_var_price >> reserve_down__var_price__out_of_sample[t * 4 + i];
            if (fin_reserve_down_var_price.eof()) error ("read_data", "Unexpected end of reserve price data file.");
        }

        for (int i = 0; i < 4; ++i) {
            fin_reserve_up_var_price >> reserve_up__var_price__in_sample[t * 4 + i];
            if (fin_reserve_up_var_price.eof()) error ("read_data", "Unexpected end of reserve price data file.");

            fin_reserve_down_var_price >> reserve_down__var_price__in_sample[t * 4 + i];
            if (fin_reserve_down_var_price.eof()) error ("read_data", "Unexpected end of reserve price data file.");
        }
    }

    double variance_of_log_reserve_up_capacity_fee;
    fin_reserve_up_cap_fee >> variance_of_log_reserve_up_capacity_fee;
    if (fin_reserve_up_cap_fee.eof()) error ("read_data", "Unexpected end of reserve price data file.");

    double variance_of_log_reserve_down_capacity_fee;
    fin_reserve_down_cap_fee >> variance_of_log_reserve_down_capacity_fee;
    if (fin_reserve_down_cap_fee.eof()) error ("read_data", "Unexpected end of reserve price data file.");

    double variance_of_reserve_up_var_price;
    fin_reserve_up_var_price >> variance_of_reserve_up_var_price;
    if (fin_reserve_up_var_price.eof()) error ("read_data", "Unexpected end of reserve price data file.");

    double variance_of_reserve_down_var_price;
    fin_reserve_down_var_price >> variance_of_reserve_down_var_price;
    if (fin_reserve_down_var_price.eof()) error ("read_data", "Unexpected end of reserve price data file.");
    
    // ensure that past in-sample reserve prices coincide with out-of-sample reserve prices
    for (int d = 0; d < current_day; ++d)
        for (int h = 0; h < no_of_hours_per_day; ++h) {
            reserve_up__capacity_fee__in_sample[d * no_of_hours_per_day + h] = reserve_up__capacity_fee__out_of_sample[d * no_of_hours_per_day + h];
            reserve_down__capacity_fee__in_sample[d * no_of_hours_per_day + h] = reserve_down__capacity_fee__out_of_sample[d * no_of_hours_per_day + h];
            for (int i = 0; i < 4; ++i) {
                reserve_up__var_price__in_sample[(d * no_of_hours_per_day + h) * 4 + i] = reserve_up__var_price__out_of_sample[(d * no_of_hours_per_day + h) * 4 + i];
                reserve_down__var_price__in_sample[(d * no_of_hours_per_day + h) * 4 + i] = reserve_down__var_price__out_of_sample[(d * no_of_hours_per_day + h) * 4 + i];
            }
        }

    cout << "done: " << toc() << " seconds." << endl;
    
    
    /*
     *******************
     *** INFLOW DATA ***
     *******************
     */
    
    tic();
    cout << "Reading inflows..." << flush;

    // reserve space
    inflows__in_sample.resize (no_of_insample_scenarios__data);
    for (int s = 0; s < no_of_insample_scenarios__data; ++s) {
        inflows__in_sample[s].resize (no_of_reservoirs);
        for (int r = 0; r < no_of_reservoirs; ++r)
            inflows__in_sample[s][r].resize (no_of_hours_per_year);
    }
    
    inflows__out_of_sample.resize (no_of_reservoirs);
    for (int r = 0; r < no_of_reservoirs; ++r)
        inflows__out_of_sample[r].resize (no_of_hours_per_year);

    // read inflows
    filename.str (string());
    filename << directory << "/proc/inflows.txt";
    ifstream fin_inflows (filename.str().c_str());

    for (int t = 0; t < no_of_hours_per_year; ++t) {
        for (int s = 0; s < no_of_insample_scenarios__data; ++s)
            for (int r = 0; r < no_of_reservoirs; ++r) {
                fin_inflows >> inflows__in_sample[s][r][t];
                if (fin_inflows.eof()) error ("read_data", "Unexpected end of inflows data file.");
            }
        
        for (int r = 0; r < no_of_reservoirs; ++r) {
            fin_inflows >> inflows__out_of_sample[r][t];
            if (fin_inflows.eof()) error ("read_data", "Unexpected end of inflows data file.");
        }
    }
    
    fin_inflows.close();
    
    // ensure that in-sample inflows of past and current day coincide with out-of-sample inflows
    for (int d = 0; d <= current_day; ++d)
        for (int h = 0; h < no_of_hours_per_day; ++h)
            for (int s = 0; s < no_of_insample_scenarios__data; ++s)
                for (int r = 0; r < no_of_reservoirs; ++r)
                    inflows__in_sample[s][r][d * no_of_hours_per_day + h] = inflows__out_of_sample[r][d * no_of_hours_per_day + h];
    
    cout << "done: " << toc() << " seconds." << endl;

    // that's it!
    cout << "OVERALL READING TIME: " << toc() << " seconds." << endl;
}
