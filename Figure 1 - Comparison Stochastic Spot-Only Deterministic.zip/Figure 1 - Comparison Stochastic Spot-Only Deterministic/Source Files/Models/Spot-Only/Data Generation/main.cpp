//
//  main.cpp
//  Hydroscheduling
//
//  Created by Wolfram Wiesemann on 07/07/2020.
//  Copyright © 2020 Wolfram Wiesemann. All rights reserved.
//

#include <cmath>
#include <random>
#include <vector>
#include <fstream>
#include <sstream>
#include <iostream>

#include "gurobi_c++.h"

#include "auxiliary.hpp"
#include "data_and_parameters.hpp"
#include "input_data_io.hpp"
#include "master_problem.hpp"
#include "daily_problem.hpp"

using namespace std;

int main (int argc, const char *argv[], const char *param_env[]) {
    double water_value_scaling_factor;
    // extract problem parameters
    if (argc != 4)
        error ("main", "2 arguments needed: target_reserve_success_probability_first_stage-index target_success_frequency_second_stage-index water-value-scaling-factor");
    else {
        target_reserve_success_probability_first_stage__hourly_granularity__index = atoi (argv[1]);
        target_success_frequency_second_stage__5_second_granularity__index = atoi (argv[2]);
        water_value_scaling_factor = atof (argv[3]);
    }
    
    if ((target_reserve_success_probability_first_stage__hourly_granularity__index < 0) ||
        (target_reserve_success_probability_first_stage__hourly_granularity__index >= (sizeof first_stage__probs / sizeof first_stage__probs[0])))
        error ("main", "target_reserve_success_probability_first_stage-index out of range");
    
    if ((target_success_frequency_second_stage__5_second_granularity__index < 0) ||
        (target_success_frequency_second_stage__5_second_granularity__index >= (sizeof second_stage__probs / sizeof second_stage__probs[0])))
        error ("main", "target_success_frequency_second_stage__5_second_granularity-index out of range");
    
    tic();

    // read current_day and initial_reservoir_level
    stringstream filename;
    filename << directory << "/snapshot_"
             << target_reserve_success_probability_first_stage__hourly_granularity__index << "_"
             << target_success_frequency_second_stage__5_second_granularity__index << "_" << water_value_scaling_factor << ".txt";

    ifstream fin (filename.str().c_str());
    if (fin.is_open()) {
        fin >> current_day;
        for (int r = 0; r < no_of_reservoirs; ++r)
            fin >> initial_reservoir_level[r];
    } else {
        current_day = 0;
        for (int r = 0; r < no_of_reservoirs; ++r)
            initial_reservoir_level[r] = reservoir_level__beginning_of_year[r];
    }
    fin.close();
    
    // terminate if done
    if (current_day == no_of_days_per_year)
        error ("main", "Completed the entire year; arborting.");

    // read instance data
    read_data();
    
    // solve master problem to calculate water values
    vector<double> water_values, water_target_levels;
    double violation_master = -1.0;
    solve_master_problem (water_values, water_target_levels, violation_master);
    for (int r = 0; r < no_of_reservoirs; ++r)
        water_values[r] *= water_value_scaling_factor;

    // solve subproblem for the first hour of the day
    vector<double> bid__spot;
    double violation_sub = -1.0;
    solve_first_hour_of_daily_problem (water_values, water_target_levels, bid__spot, violation_sub);

    // solve subproblem for each hour of the day
    vector<double> generate, pump, spill;
    generate.resize (no_of_arcs * no_of_hours_per_day, 0.0);
    pump.resize (no_of_arcs * no_of_hours_per_day, 0.0);
    spill.resize (no_of_arcs * no_of_hours_per_day, 0.0);
    for (int theta = 0; theta < no_of_hours_per_day; ++theta)
        solve_each_hour_of_daily_problem (theta, water_values, water_target_levels,
                                        bid__spot,
                                        generate, pump, spill, violation_sub);
    
    // calculate final_reservoir_level
    vector<double> final_reservoir_level;
    final_reservoir_level.resize (no_of_reservoirs);
    
    for (int r = 0; r < no_of_reservoirs; ++r) {
        final_reservoir_level[r] = initial_reservoir_level[r];
        for (int h = 0; h < no_of_hours_per_day; ++h) {
            final_reservoir_level[r] += inflows__in_sample[0][r][current_day * no_of_hours_per_day + h];
            for (int a = 0; a < no_of_arcs; ++a)
                final_reservoir_level[r] += topology_matrix[r][a] * (generate[a * no_of_hours_per_day + h] -
                                                                     pump[a * no_of_hours_per_day + h] +
                                                                     spill[a * no_of_hours_per_day + h]);
        }
    }

    // write revised current_day and final_reservoir_level into snapshot file
    filename.str (string());
    filename << "rm " << directory << "/snapshot_"
             << target_reserve_success_probability_first_stage__hourly_granularity__index << "_"
             << target_success_frequency_second_stage__5_second_granularity__index << "_" << water_value_scaling_factor << ".txt";
    system (filename.str().c_str());
    
    filename.str (string());
    filename << directory << "/snapshot_"
             << target_reserve_success_probability_first_stage__hourly_granularity__index << "_"
             << target_success_frequency_second_stage__5_second_granularity__index << "_" << water_value_scaling_factor << ".txt";
    ofstream fout1 (filename.str().c_str());
    fout1 << current_day + 1 << endl;
    for (int r = 0; r < no_of_reservoirs; ++r)
        fout1 << final_reservoir_level[r] << " ";
    fout1 << endl;
    fout1.close();
    
    // write statistics
    filename.str (string());
    filename << directory << "/statistics_"
             << target_reserve_success_probability_first_stage__hourly_granularity__index << "_"
             << target_success_frequency_second_stage__5_second_granularity__index << "_" << water_value_scaling_factor << ".txt";
    ofstream fout2 (filename.str().c_str(), ios_base::app);

    fout2 << current_day << endl;
    fout2 << violation_master << " " << violation_sub << endl;

    for (int r = 0; r < no_of_reservoirs; ++r)
        fout2 << initial_reservoir_level[r] << " ";
    fout2 << endl;

    for (int r = 0; r < no_of_reservoirs; ++r)
        fout2 << water_values[r] << " ";
    fout2 << endl;

    for (int r = 0; r < no_of_reservoirs; ++r)
        fout2 << water_target_levels[r] << " ";
    fout2 << endl;

    double g = 0.0, p = 0.0, s = 0.0;
    for (int h = 0; h < no_of_hours_per_day; ++h) {
        for (int a = 0; a < no_of_arcs; ++a) {
            g += generate[a * no_of_hours_per_day + h];
            p += pump[a * no_of_hours_per_day + h];
            s += spill[a * no_of_hours_per_day + h];
        }
    }
    fout2 << g << " " << p << " " << s << endl;

    for (int h = 0; h < no_of_hours_per_day; ++h) {
        double cap_fee_up, cap_fee_down, var_price_up, var_price_down;
        find_bids_for_day (current_day, cap_fee_up, cap_fee_down, var_price_up, var_price_down);

        fout2 << "  ";
        fout2 << bid__spot[h] << " " << spot_price__in_sample[current_day * no_of_hours_per_day + h] * bid__spot[h] << endl;
    }

    for (int r = 0; r < no_of_reservoirs; ++r)
        fout2 << final_reservoir_level[r] << " ";
    fout2 << endl << endl;
        
    // that's it!
    cout << "*** OVERALL TIME: " << toc() << " SECONDS. ***" << endl;
    return 0;
}
