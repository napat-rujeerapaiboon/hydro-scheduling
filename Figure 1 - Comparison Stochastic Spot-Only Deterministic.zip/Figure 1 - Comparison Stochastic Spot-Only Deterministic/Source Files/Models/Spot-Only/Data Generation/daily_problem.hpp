//
//  daily_problem.hpp
//  Hydroscheduling
//
//  Created by Wolfram Wiesemann on 01/12/2020.
//  Copyright © 2020 Wolfram Wiesemann. All rights reserved.
//

#ifndef daily_problem_hpp
#define daily_problem_hpp

#include <vector>

double solve_first_hour_of_daily_problem (const std::vector<double> &water_values, const std::vector<double> &water_target_levels,
                                          std::vector<double> &result_s, double &violation);

double solve_each_hour_of_daily_problem (int theta, const std::vector<double> &water_values, const std::vector<double> &water_target_levels,
                                         const std::vector<double> &bid__spot,
                                         std::vector<double> &res_generate, std::vector<double> &res_pump, std::vector<double> &res_spill, double &violation);

#endif /* daily_problem_hpp */
