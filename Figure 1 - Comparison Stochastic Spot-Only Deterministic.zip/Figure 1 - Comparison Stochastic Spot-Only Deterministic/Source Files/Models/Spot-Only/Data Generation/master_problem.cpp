//
//  master_problem.cpp
//  Hydroscheduling
//
//  Created by Wolfram Wiesemann on 01/12/2020.
//  Copyright © 2020 Wolfram Wiesemann. All rights reserved.
//

#include "master_problem.hpp"

#include <fstream>

#include "gurobi_c++.h"

#include "auxiliary.hpp"
#include "data_and_parameters.hpp"
#include "input_data_io.hpp"

using namespace std;

double solve_master_problem (vector<double> &water_values, vector<double> &water_target_levels, double &violation) {
    // set up model
    GRBEnv *env = new GRBEnv();
    GRBModel model = GRBModel (*env);

    model.set (GRB_IntParam_Method, 2);
    //model.set (GRB_IntParam_Threads, 1);
    model.set (GRB_IntParam_Crossover, 0);

    tic();
    
    // set up decision variables
    tic();
    cout << "Setting up decision variables..." << flush;
    
    GRBVar *bid__spot         = model.addVars (no_of_insample_scenarios__model * no_of_hours_per_year);

    GRBVar *generate = model.addVars (no_of_insample_scenarios__model * no_of_arcs * no_of_hours_per_year);
    GRBVar *pump     = model.addVars (no_of_insample_scenarios__model * no_of_arcs * no_of_hours_per_year);
    GRBVar *spill    = model.addVars (no_of_insample_scenarios__model * no_of_arcs * no_of_hours_per_year);

    GRBVar *initial_water_level = model.addVars (no_of_reservoirs);             // to obtain shadow prices
    GRBVar *water_level = model.addVars (no_of_insample_scenarios__model * no_of_reservoirs * no_of_days_per_year);
    GRBVar *water_level__LDR__intercept = model.addVars (no_of_reservoirs * no_of_days_per_year);
    GRBVar *water_level__LDR__slope_cum_inflow_curr_day = model.addVars (no_of_reservoirs * no_of_days_per_year * no_of_reservoirs);
    GRBVar *water_level__LDR__slope_cum_inflow_past = model.addVars (no_of_reservoirs * no_of_days_per_year * no_of_reservoirs);
    GRBVar *water_level__LDR__slope_avg_spot_curr_day = model.addVars (no_of_reservoirs * no_of_days_per_year);
    
    cout << "done: " << toc() << " seconds." << endl;
    
    GRBLinExpr expr;
    
    // set up objective function
    tic();
    cout << "Setting up objective function..." << flush;

    expr = 0;
    for (int s = 0; s < no_of_insample_scenarios__model; ++s)
        for (int d = 0; d < no_of_days_per_year; ++d) {
            for (int h = 0; h < no_of_hours_per_day; ++h) {
                double cap_fee_up, cap_fee_down, var_price_up, var_price_down;
                find_bids_for_day ((current_day + d) % no_of_days_per_year, cap_fee_up, cap_fee_down, var_price_up, var_price_down);
                
                // spot market revenues
                expr += spot_price__in_sample[((current_day + d) * no_of_hours_per_day + h) % no_of_hours_per_year] *
                        bid__spot[(s * no_of_days_per_year + d) * no_of_hours_per_day + h];
            }
        }
    model.setObjective (expr / (double)(no_of_insample_scenarios__model), GRB_MAXIMIZE);
    
    cout << "done: " << toc() << " seconds." << endl;

    // set up variable bounds
    tic();
    cout << "Setting up variable bounds..." << flush;

    for (int s = 0; s < no_of_insample_scenarios__model; ++s)
        for (int t = 0; t < no_of_hours_per_year; ++t)
            bid__spot[s * no_of_hours_per_year + t].set (GRB_DoubleAttr_LB, -GRB_INFINITY);     // negative values = pumping

    for (int s = 0; s < no_of_insample_scenarios__model; ++s)
        for (int t = 0; t < no_of_hours_per_year; ++t)
            for (int a = 0; a < no_of_arcs; ++a) {
                generate[(s * no_of_arcs + a) * no_of_hours_per_year + t].set (GRB_DoubleAttr_UB, ub_generation[a]);
                pump[(s * no_of_arcs + a) * no_of_hours_per_year + t].set (GRB_DoubleAttr_UB, ub_pumping[a]);
            }
    
    for (int r = 0; r < no_of_reservoirs; ++r)
        for (int d = 0; d < no_of_days_per_year; ++d) {
            for (int s = 0; s < no_of_insample_scenarios__model; ++s) {
                water_level[(s * no_of_reservoirs + r) * no_of_days_per_year + d].set (GRB_DoubleAttr_LB, lb_reservoir_level[r]);
                water_level[(s * no_of_reservoirs + r) * no_of_days_per_year + d].set (GRB_DoubleAttr_UB, ub_reservoir_level[r]);
            }

            water_level__LDR__intercept[r * no_of_days_per_year + d].set (GRB_DoubleAttr_LB, -GRB_INFINITY);
            for (int rr = 0; rr < no_of_reservoirs; ++rr) {
                water_level__LDR__slope_cum_inflow_curr_day[(r * no_of_days_per_year + d) * no_of_reservoirs + rr].set (GRB_DoubleAttr_LB, -GRB_INFINITY);
                water_level__LDR__slope_cum_inflow_past[(r * no_of_days_per_year + d) * no_of_reservoirs + rr].set (GRB_DoubleAttr_LB, -GRB_INFINITY);
            }
            water_level__LDR__slope_avg_spot_curr_day[r * no_of_days_per_year + d].set (GRB_DoubleAttr_LB, -GRB_INFINITY);
        }
        
    cout << "done: " << toc() << " seconds." << endl;

    // set up constraints: initial water level (for shadow prices)
    tic();
    cout << "Setting up initial water level constraints..." << flush;

    vector<GRBConstr> initial_water_level_constraints;
    for (int r = 0; r < no_of_reservoirs; ++r)
        initial_water_level_constraints.push_back (model.addConstr (initial_water_level[r] == initial_reservoir_level[r]));
    
    cout << "done: " << toc() << " seconds." << endl;

    // set up constraints: robust market fulfillment
    tic();
    cout << "Setting up robust market fulfillment constraints..." << flush;

    double maximum_pumping_quantity = 0.0;
    for (int a = 0; a < no_of_arcs; ++a)
        maximum_pumping_quantity += inverse_pump_efficiency[a] * ub_pumping[a];
    
    double rho_upperbar_u, rho_upperbar_v;
    //get_rhos (rho_upperbar_u, rho_upperbar_v);
    rho_upperbar_u = 1.0; rho_upperbar_v = 1.0;

    for (int s = 0; s < no_of_insample_scenarios__model; ++s)
        for (int t = 0; t < no_of_hours_per_year; ++t) {
            expr = 0;
            for (int a = 0; a < no_of_arcs; ++a)
                expr += generator_efficiency[a] * generate[(s * no_of_arcs + a) * no_of_hours_per_year + t] -
                        inverse_pump_efficiency[a] * pump[(s * no_of_arcs + a) * no_of_hours_per_year + t];
            model.addConstr (bid__spot[s * no_of_hours_per_year + t] == expr);
            
            model.addConstr (bid__spot[s * no_of_hours_per_year + t] >= -maximum_pumping_quantity);
        }
        
    cout << "done: " << toc() << " seconds." << endl;

    // set up constraints: hourly water level dynamics
    tic();
    cout << "Setting up hourly water level dynamics constraints..." << flush;

    for (int s = 0; s < no_of_insample_scenarios__model; ++s)
        for (int r = 0; r < no_of_reservoirs; ++r)
            for (int t = 0; t < no_of_hours_per_year; ++t) {
                if (day_of_hour (t) == 0)
                    expr = initial_water_level[r];
                else
                    expr = water_level[(s * no_of_reservoirs + r) * no_of_days_per_year + day_of_hour (t) - 1];
                                                
                for (int tt = first_hour_of_day (day_of_hour (t)); tt <= t; ++tt) {
                    expr += inflows__in_sample[s][r][(current_day * no_of_hours_per_day + tt) % no_of_hours_per_year];
                    for (int a = 0; a < no_of_arcs; ++a)
                        expr += topology_matrix[r][a] *
                                (generate[(s * no_of_arcs + a) * no_of_hours_per_year + tt] -
                                 pump[(s * no_of_arcs + a) * no_of_hours_per_year + tt] +
                                 spill[(s * no_of_arcs + a) * no_of_hours_per_year + tt]);
                }
                
                model.addRange (expr, lb_reservoir_level[r], ub_reservoir_level[r]);
                
                if (t == last_hour_of_day (day_of_hour (t)))
                    model.addConstr (expr >= water_level[(s * no_of_reservoirs + r) * no_of_days_per_year + day_of_hour (t)]);
            }
    
    cout << "done: " << toc() << " seconds." << endl;

    // set up constraints: linear decision rules for water level targets
    tic();
    cout << "Setting up linear decision rules for water level targets..." << flush;
    
    for (int s = 0; s < no_of_insample_scenarios__model; ++s)
        for (int r = 0; r < no_of_reservoirs; ++r)
            for (int d = 0; d < no_of_days_per_year; ++d) {
                double coeff__avg_spot_curr_day = 0.0;
                for (int t = first_hour_of_day (d); t < first_hour_of_day (d + 1); ++t)
                    coeff__avg_spot_curr_day += spot_price__in_sample[(current_day * no_of_hours_per_day + t) % no_of_hours_per_year];
                
                expr = water_level__LDR__intercept[r * no_of_days_per_year + d] +
                       coeff__avg_spot_curr_day * water_level__LDR__slope_avg_spot_curr_day[r * no_of_days_per_year + d];
                
                for (int rr = 0; rr < no_of_reservoirs; ++rr) {
                    double coeff__cum_inflow_curr_day = 0.0;
                    for (int t = first_hour_of_day (d); t < first_hour_of_day (d + 1); ++t)
                        coeff__cum_inflow_curr_day += inflows__in_sample[s][rr][(current_day * no_of_hours_per_day + t) % no_of_hours_per_year];
                                            
                    double coeff__cum_inflow_past = 0.0;
                    for (int t = 0; t < first_hour_of_day (d); ++t)
                        coeff__cum_inflow_past += inflows__in_sample[s][rr][(current_day * no_of_hours_per_day + t) % no_of_hours_per_year];
                    
                    expr += coeff__cum_inflow_curr_day *
                            water_level__LDR__slope_cum_inflow_curr_day[(r * no_of_days_per_year + d) * no_of_reservoirs + rr] +
                            coeff__cum_inflow_past *
                            water_level__LDR__slope_cum_inflow_past[(r * no_of_days_per_year + d) * no_of_reservoirs + rr];
                }
                model.addConstr (water_level[(s * no_of_reservoirs + r) * no_of_days_per_year + d] == expr);
            }
    
    cout << "done: " << toc() << " seconds." << endl;
    
    cout << "*** OVERALL SETUP TIME: " << toc() << " SECONDS. ***" << endl;

    // solve the problem
    model.optimize();

    if (model.get (GRB_IntAttr_Status) != GRB_OPTIMAL) {
        cerr << "*** OPTIMIZATION PROBLEM IS INFEASIBLE -- TRYING RELAXATION ***" << endl;
        
        // solve relaxed model just to get the violation value
        model.update();
        GRBModel violation_model = model;
        violation_model.feasRelax (0, false, true, true);
        violation_model.optimize();
        if (violation_model.get (GRB_IntAttr_Status) != GRB_OPTIMAL)
            error ("solve_master_problem", "Relaxed optimization problem not solved to optimality.");
        violation = violation_model.get(GRB_DoubleAttr_ObjVal);
        cerr << "Objective value of feasibility relaxation: " << violation << endl;
        
        // now get best solution for relaxed model to continue
        model.feasRelax (0, true, true, true);
        model.optimize();
        if (model.get (GRB_IntAttr_Status) != GRB_OPTIMAL)
            error ("solve_master_problem", "Relaxed optimization problem not solved to optimality.");
    } else violation = -1.0;
    
    double obj_value = model.get(GRB_DoubleAttr_ObjVal);
    
    // store water values
    water_values.clear();
    for (int r = 0; r < no_of_reservoirs; ++r) {
        double wv = initial_water_level_constraints[r].get (GRB_DoubleAttr_Pi);
        cout << "WATER VALUE " << r << ": " << wv << endl;
        water_values.push_back (wv);
    }

    // store water levels targets
    water_target_levels.clear();
    for (int r = 0; r < no_of_reservoirs; ++r) {
        cout << "reservoir " << r << ": initial water level = " << initial_water_level[r].get (GRB_DoubleAttr_X) << endl;
        for (int s = 0; s < no_of_insample_scenarios__model; ++s)
            cout << "    water_target_levels[" << s << "] = " << water_level[(s * no_of_reservoirs + r) * no_of_days_per_year + 0].get (GRB_DoubleAttr_X) << endl;
        water_target_levels.push_back (water_level[(0 * no_of_reservoirs + r) * no_of_days_per_year + 0].get (GRB_DoubleAttr_X));
    }

    //ofstream fout ("/Users/wolframwiesemann/Desktop/water_levels__master_problem.csv");
    //for (int d = 0; d < no_of_days_per_year; ++d)
    //    for (int s = 0; s < no_of_insample_scenarios__model; ++s) {
    //        fout << water_level[(s * no_of_reservoirs + 0) * no_of_days_per_year + d].get (GRB_DoubleAttr_X);
    //        if (s < no_of_insample_scenarios__model - 1) fout << ", "; else fout << endl;
    //    }
    //fout.close();
    
    // de-allocate variables
    delete []bid__spot;

    delete []generate;
    delete []pump;
    delete []spill;

    delete []initial_water_level;
    delete []water_level;
    delete []water_level__LDR__intercept;
    delete []water_level__LDR__slope_cum_inflow_curr_day;
    delete []water_level__LDR__slope_cum_inflow_past;
    delete []water_level__LDR__slope_avg_spot_curr_day;
    
    // that's it!
    return obj_value;
}
