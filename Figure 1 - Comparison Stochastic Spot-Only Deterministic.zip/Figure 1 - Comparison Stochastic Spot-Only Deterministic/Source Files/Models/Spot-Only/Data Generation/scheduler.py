import os
import sys
import time

for i in range (364):
    while True:
        os.system ('qstat | grep "energy.pbs" | wc -l > temp.txt')
        with open('temp.txt') as f:
            contents = f.read()
        if int(contents) == 0:
            break
        time.sleep(60)

    if (i % 10) == 9:
        os.system ("rm *.pbs.e*")
        os.system ("rm *.pbs.o*")
    
    os.system ('qsub -J 0-249 energy.pbs')
