import os
import sys

jobno = int (os.environ.get('PBS_ARRAY_INDEX'))

pp1 = pp2 = ps = -1

counter = 0
for p1 in range(5):
    for p2 in range(5):
        for scaling in (0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0):
            if counter == jobno:
                pp1 = p1; pp2 = p2; ps = scaling
            counter = counter + 1

if pp1 == -1:
    print ("argument not recognized.")
    sys.exit()
            
os.system ("./a.out " + str(pp1) + " " + str(pp2) + " " + str(ps));

#for p1 in (int(sys.argv[1]),):
#    for p2 in range (5):
#        for scaling in (0.25, 0.5, 0.75, 1.0):
#            os.system ('rm "/Users/wolframwiesemann/Desktop/snapshot_' + str(p1) + '_' + str(p2) + '_' + str(scaling) + '.txt"');
#            os.system ('rm "/Users/wolframwiesemann/Desktop/statistics_' + str(p1) + '_' + str(p2) + '_' + str(scaling) + '.txt"');
#
#            for d in range (364):
#                os.system ("./a.out " + str(p1) + " " + str(p2) + " " + str(scaling));

