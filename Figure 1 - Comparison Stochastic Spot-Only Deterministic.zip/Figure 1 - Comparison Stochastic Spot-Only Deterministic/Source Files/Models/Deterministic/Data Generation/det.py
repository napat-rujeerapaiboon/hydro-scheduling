import sys
import os

for d in range (364):
    os.system ("./a.out " + sys.argv[1] + " " + sys.argv[2] + " 1");
