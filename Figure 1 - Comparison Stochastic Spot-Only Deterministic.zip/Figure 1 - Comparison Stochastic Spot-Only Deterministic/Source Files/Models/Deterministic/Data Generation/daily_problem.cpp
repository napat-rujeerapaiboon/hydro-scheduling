//
//  daily_problem.cpp
//  Hydroscheduling
//
//  Created by Wolfram Wiesemann on 01/12/2020.
//  Copyright © 2020 Wolfram Wiesemann. All rights reserved.
//

#include "daily_problem.hpp"

#include <sstream>

#include "gurobi_c++.h"

#include "auxiliary.hpp"
#include "data_and_parameters.hpp"
#include "input_data_io.hpp"

using namespace std;

bool solve_first_hour_of_daily_problem (const vector<double> &water_values, const vector<double> &water_target_levels,
                                          vector<double> &result_s, vector<double> &result_u, vector<double> &result_v, double &violation) {
    // set up model
    GRBEnv *env = new GRBEnv();
    GRBModel model = GRBModel (*env);

    model.set (GRB_IntParam_Method, 2);
    model.set (GRB_IntParam_Threads, 1);
    model.set (GRB_IntParam_Crossover, 0);

    // set up decision variables
    GRBVar *bid__spot         = model.addVars (no_of_hours_per_day);
    GRBVar *bid__reserve_up   = model.addVars (no_of_hours_per_day);
    GRBVar *bid__reserve_down = model.addVars (no_of_hours_per_day);

    GRBVar *exp_generate    = model.addVars (no_of_arcs * no_of_hours_per_day);
    GRBVar *exp_pump        = model.addVars (no_of_arcs * no_of_hours_per_day);
    GRBVar *exp_spill       = model.addVars (no_of_arcs * no_of_hours_per_day);

    GRBLinExpr expr, expr2;
    
    // set up objective function
    expr = 0;
    
    for (int h = 0; h < no_of_hours_per_day; ++h) {
        double cap_fee_up, cap_fee_down, var_price_up, var_price_down;
        find_bids_for_day (current_day, cap_fee_up, cap_fee_down, var_price_up, var_price_down);
        
        // spot market revenues
        expr += spot_price__in_sample[current_day * no_of_hours_per_day + h] * bid__spot[h];
        
        // reserve-up market revenues
        expr += first_stage__probs[target_reserve_success_probability_first_stage__hourly_granularity__index] *
                (cap_fee_up + second_stage__probs[target_success_frequency_second_stage__5_second_granularity__index] * var_price_up) *
                bid__reserve_up[h];
        
        // reserve-down market revenues
        expr += first_stage__probs[target_reserve_success_probability_first_stage__hourly_granularity__index] *
                (cap_fee_down + second_stage__probs[target_success_frequency_second_stage__5_second_granularity__index] * (-var_price_down)) *
                bid__reserve_down[h];

        // water values
        for (int r = 0; r < no_of_reservoirs; ++r) {
            expr += water_values[r] * inflows__in_sample[0][r][current_day * no_of_hours_per_day + h];
            for (int a = 0; a < no_of_arcs; ++a)
                expr += water_values[r] * topology_matrix[r][a] * (exp_generate[a * no_of_hours_per_day + h] -
                                                                   exp_pump[a * no_of_hours_per_day + h] +
                                                                   exp_spill[a * no_of_hours_per_day + h]);
        }
    }
    
    model.setObjective (expr, GRB_MAXIMIZE);

    // set up variable bounds
    for (int h = 0; h < no_of_hours_per_day; ++h)
        bid__spot[h].set (GRB_DoubleAttr_LB, -GRB_INFINITY);            // negative values correspond to pumping
    
    for (int h = 0; h < no_of_hours_per_day; ++h)
        for (int a = 0; a < no_of_arcs; ++a) {
            exp_generate[a * no_of_hours_per_day + h].set (GRB_DoubleAttr_UB, ub_generation[a]);
            exp_pump[a * no_of_hours_per_day + h].set (GRB_DoubleAttr_UB, ub_pumping[a]);
        }

    // check whether spot-only investment
    if (invest_in_spot_market_only) {
        for (int h = 0; h < no_of_hours_per_day; ++h) {
            bid__reserve_up[h].set (GRB_DoubleAttr_UB, 0.0);
            bid__reserve_down[h].set (GRB_DoubleAttr_UB, 0.0);
        }
    }

    // set up constraints: block bidding
    for (int h = 0; h < 24; h += 4)
        for (int i = 1; i < 4; ++i) {
            model.addConstr (bid__reserve_up[h + i] == bid__reserve_up[h]);
            model.addConstr (bid__reserve_down[h + i] == bid__reserve_down[h]);
        }
    
    // set up constraints: suv-constraints
    double rho_upperbar_u, rho_upperbar_v;
    //get_rhos (rho_upperbar_u, rho_upperbar_v);
    rho_upperbar_u = 1.0; rho_upperbar_v = 1.0;

    for (int h = 0; h < no_of_hours_per_day; ++h) {
        expr = 0;
        for (int a = 0; a < no_of_arcs; ++a)
            expr += generator_efficiency[a] * exp_generate[a * no_of_hours_per_day + h] -
                    inverse_pump_efficiency[a] * exp_pump[a * no_of_hours_per_day + h];
        model.addConstr (bid__spot[h] +
                         first_stage__probs[target_reserve_success_probability_first_stage__hourly_granularity__index] * second_stage__probs[target_success_frequency_second_stage__5_second_granularity__index] * bid__reserve_up[h] -
                         first_stage__probs[target_reserve_success_probability_first_stage__hourly_granularity__index] * second_stage__probs[target_success_frequency_second_stage__5_second_granularity__index] * bid__reserve_down[h] == expr);

        model.addConstr (bid__reserve_up[h] + bid__reserve_down[h] <= bid__spot[h]);
    }
    
    // set up constraints: hourly water level dynamics
    for (int r = 0; r < no_of_reservoirs; ++r)
        for (int h = 0; h < no_of_hours_per_day; ++h) {
            expr = initial_reservoir_level[r];
            for (int hh = 0; hh <= h; ++hh) {
                expr += inflows__in_sample[0][r][current_day * no_of_hours_per_day + hh];
                for (int a = 0; a < no_of_arcs; ++a)
                    expr += topology_matrix[r][a] * (exp_generate[a * no_of_hours_per_day + hh] -
                                                     exp_pump[a * no_of_hours_per_day + hh] +
                                                     exp_spill[a * no_of_hours_per_day + hh]);
            }
            // we are accounting here for the end-of-day water target constraints!
            if (h < no_of_hours_per_day - 1)
                model.addRange (expr, lb_reservoir_level[r], ub_reservoir_level[r]);
            else
                model.addRange (expr, max (lb_reservoir_level[r], water_target_levels[r]), ub_reservoir_level[r]);
        }
    
    // solve the problem
    model.optimize();
    
    if (model.get (GRB_IntAttr_Status) != GRB_OPTIMAL) return false;
    
    double obj_value = model.get(GRB_DoubleAttr_ObjVal);
    
    // store the bidding strategy
    result_s.clear();
    result_u.clear();
    result_v.clear();
    for (int h = 0; h < no_of_hours_per_day; ++h) {
        result_s.push_back (bid__spot[h].get (GRB_DoubleAttr_X));
        result_u.push_back (bid__reserve_up[h].get (GRB_DoubleAttr_X));
        result_v.push_back (bid__reserve_down[h].get (GRB_DoubleAttr_X));
    }
    
    // de-allocate variables
    delete []bid__spot;
    delete []bid__reserve_up;
    delete []bid__reserve_down;

    delete []exp_generate;
    delete []exp_pump;
    delete []exp_spill;

    // that's it!
    return true;
}


bool solve_each_hour_of_daily_problem (int theta, const vector<double> &water_values, const vector<double> &water_target_levels,
                                         const vector<double> &bid__spot, const vector<double> &bid__reserve_up, const vector<double> &bid__reserve_down,
                                         vector<double> &res_generate, vector<double> &res_pump, vector<double> &res_spill, double &violation) {
    // set up model
    GRBEnv *env = new GRBEnv();
    GRBModel model = GRBModel (*env);

    model.set (GRB_IntParam_Method, 2);
    model.set (GRB_IntParam_Threads, 1);
    model.set (GRB_IntParam_Crossover, 0);

    // set up decision variables
    GRBVar *var_exp_generate    = model.addVars (no_of_arcs * no_of_hours_per_day);
    GRBVar *var_exp_pump        = model.addVars (no_of_arcs * no_of_hours_per_day);
    GRBVar *var_exp_spill       = model.addVars (no_of_arcs * no_of_hours_per_day);

    GRBLinExpr expr, expr2;

    // set up objective function
    expr = 0;
    
    for (int r = 0; r < no_of_reservoirs; ++r)
        for (int a = 0; a < no_of_arcs; ++a) {
            for (int h = theta; h < no_of_hours_per_day; ++h)
                expr += water_values[r] * topology_matrix[r][a] * (var_exp_generate[a * no_of_hours_per_day + h] -
                                                                   var_exp_pump[a * no_of_hours_per_day + h] +
                                                                   var_exp_spill[a * no_of_hours_per_day + h]);
        }

    model.setObjective (expr, GRB_MAXIMIZE);

    // set up variable bounds
    for (int h = 0; h < no_of_hours_per_day; ++h)
        for (int a = 0; a < no_of_arcs; ++a) {
            var_exp_generate[a * no_of_hours_per_day + h].set (GRB_DoubleAttr_UB, ub_generation[a]);
            var_exp_pump[a * no_of_hours_per_day + h].set (GRB_DoubleAttr_UB, ub_pumping[a]);
        }

    // set up constraints: suv-constraint for theta
    double cap_fee_up, cap_fee_down, var_price_up, var_price_down;
    find_bids_for_day (current_day, cap_fee_up, cap_fee_down, var_price_up, var_price_down);

    bool reserve_up__first_round_success = (cap_fee_up <= reserve_up__capacity_fee__out_of_sample[current_day * no_of_hours_per_day + theta]);
    bool reserve_down_first_round_success = (cap_fee_down <= reserve_down__capacity_fee__out_of_sample[current_day * no_of_hours_per_day + theta]);

    double reserve_up__second_round_frequency = 0.0, reserve_down__second_round_frequency = 0.0;
    for (int i = 0; i < 4; ++i) {
        if (var_price_up <= reserve_up__var_price__out_of_sample[(current_day * no_of_hours_per_day + theta) * 4 + i])
            reserve_up__second_round_frequency += 0.25;
        if (var_price_down >= reserve_down__var_price__out_of_sample[(current_day * no_of_hours_per_day + theta) * 4 + i])
            reserve_down__second_round_frequency += 0.25;
    }
    
    expr = bid__spot[theta];
    if (reserve_up__first_round_success) expr += reserve_up__second_round_frequency * bid__reserve_up[theta];
    if (reserve_down_first_round_success) expr -= reserve_down__second_round_frequency * bid__reserve_down[theta];
    
    expr2 = 0;
    for (int a = 0; a < no_of_arcs; ++a)
        expr2 += generator_efficiency[a] * var_exp_generate[a * no_of_hours_per_day + theta] -
                 inverse_pump_efficiency[a] * var_exp_pump[a * no_of_hours_per_day + theta];
    model.addConstr (expr == expr2);
    
    // set up constraints: suv-constraint for h > theta
    double rho_upperbar_u, rho_upperbar_v;
    //get_rhos (rho_upperbar_u, rho_upperbar_v);
    rho_upperbar_u = 1.0; rho_upperbar_v = 1.0;

    for (int h = theta + 1; h < no_of_hours_per_day; ++h) {
        find_bids_for_day (current_day, cap_fee_up, cap_fee_down, var_price_up, var_price_down);

        expr = 0;
        for (int a = 0; a < no_of_arcs; ++a)
            expr += generator_efficiency[a] * var_exp_generate[a * no_of_hours_per_day + h] -
                    inverse_pump_efficiency[a] * var_exp_pump[a * no_of_hours_per_day + h];
        
        double ind_reserve_up__first_round_success = (cap_fee_up <= reserve_up__capacity_fee__out_of_sample[current_day * no_of_hours_per_day + h]) ? 1.0 : 0.0;
        double ind_reserve_down_first_round_success = (cap_fee_down <= reserve_down__capacity_fee__out_of_sample[current_day * no_of_hours_per_day + h]) ? 1.0 : 0.0;

        model.addConstr (bid__spot[h] +
                         ind_reserve_up__first_round_success *
                         second_stage__probs[target_success_frequency_second_stage__5_second_granularity__index] *
                         bid__reserve_up[h]
                         - ind_reserve_down_first_round_success *
                         second_stage__probs[target_success_frequency_second_stage__5_second_granularity__index] * bid__reserve_down[h]
                         == expr);
    }

    // set up constraints: hourly water level dynamics
    for (int r = 0; r < no_of_reservoirs; ++r)
        for (int h = theta; h < no_of_hours_per_day; ++h) {
            expr = initial_reservoir_level[r];
            for (int hh = 0; hh <= h; ++hh) {
                expr += inflows__in_sample[0][r][current_day * no_of_hours_per_day + hh];
                for (int a = 0; a < no_of_arcs; ++a) {
                    if (hh >= theta)
                        expr += topology_matrix[r][a] * (var_exp_generate[a * no_of_hours_per_day + hh] -
                                                         var_exp_pump[a * no_of_hours_per_day + hh] +
                                                         var_exp_spill[a * no_of_hours_per_day + hh]);
                    else
                        expr += topology_matrix[r][a] * (res_generate[a * no_of_hours_per_day + hh] -
                                                         res_pump[a * no_of_hours_per_day + hh] +
                                                         res_spill[a * no_of_hours_per_day + hh]);
                }
            }
            // we are accounting here for the end-of-day water target constraints!
            if (h < no_of_hours_per_day - 1)
                model.addRange (expr, lb_reservoir_level[r], ub_reservoir_level[r]);
            else
                model.addRange (expr, max (lb_reservoir_level[r], water_target_levels[r]), ub_reservoir_level[r]);
        }

    // solve the problem
    model.optimize();
    
    if (model.get (GRB_IntAttr_Status) != GRB_OPTIMAL) return false;
    
    double obj_value = model.get(GRB_DoubleAttr_ObjVal);
    
    // record the generation, pump and spill decisions
    for (int a = 0; a < no_of_arcs; ++a) {
        res_generate[a * no_of_hours_per_day + theta] = var_exp_generate[a * no_of_hours_per_day + theta].get (GRB_DoubleAttr_X);
        res_pump[a * no_of_hours_per_day + theta] = var_exp_pump[a * no_of_hours_per_day + theta].get (GRB_DoubleAttr_X);
        res_spill[a * no_of_hours_per_day + theta] = var_exp_spill[a * no_of_hours_per_day + theta].get (GRB_DoubleAttr_X);
    }
    
    // de-allocate variables
    delete []var_exp_generate;
    delete []var_exp_pump;
    delete []var_exp_spill;

    // that's it!
    return true;
}
