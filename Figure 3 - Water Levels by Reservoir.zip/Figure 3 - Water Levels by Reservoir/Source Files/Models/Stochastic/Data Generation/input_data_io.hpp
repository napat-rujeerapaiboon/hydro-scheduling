//
//  input_data_io.hpp
//  Hydroscheduling
//
//  Created by Wolfram Wiesemann on 01/12/2020.
//  Copyright © 2020 Wolfram Wiesemann. All rights reserved.
//

#ifndef input_data_io_hpp
#define input_data_io_hpp

// read the input data -- current_day needed to set in-sample data equal to out-of-sample data for past + (partly) present
void read_data();

// get bid prices for a particular day
void find_bids_for_day (int day, double &cap_fee_up, double &cap_fee_down, double &var_price_up, double &var_price_down);

#endif /* input_data_io_hpp */
