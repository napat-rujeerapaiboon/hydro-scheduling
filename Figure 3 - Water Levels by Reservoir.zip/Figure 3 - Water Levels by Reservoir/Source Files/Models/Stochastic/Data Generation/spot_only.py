import sys
import os

for d in range (364):
    os.system ("./a.out 0 0 1");
